"""-*- 老婆最美 -*-"""
# @Project : MatchongFusion.py
# @File : TrainDescriptorNet.py 
# @Time : 2023/12/3 11:05 
# @Author : WaiL 
# @Software: PyCharm
"""
功能：训练深度描述子
"""
import numpy as np
from PIL import Image
from torchvision.transforms import Compose, ToTensor, Normalize, Lambda
from Code.FeatureDescription.Preprocessing import preprocessing_gray, preprocessing_size, preprocessing_texture, preprocessing_color, preprocessing_mask_image, plot_texture_features
import random
from Code.FeatureDescription.CreateDataset import split_train_validation_dataset, TheDataset
from Code.ToolsForThePaper.ReadFoldersFilesOrderWindows import ReadAllFile_WindowsOrder, ReadAllFile_FlattenedOrder
from Code.ToolsForThePaper.SaveData import save_data
import os
from torch.utils.data import DataLoader
import argparse
from Code.FeatureDescription.DescriptorNet import MultiHeadAttentionDescriptor
import torch
import torch.nn as nn
from Code.ToolsForThePaper.pytorchssimmaster.pytorch_ssim import SSIM
from tqdm import tqdm
import sys
from Code.ToolsForThePaper.TextSound import text_sound
import scipy.io


# 定义训练函数
def train(model, train_loader, criterion, optimizer, device, epoch):
    # 加载模型参数[从训练中断始]
    # if epoch == 41:
    #     model_parameter = torch.load(r'ModelParameter/descriptor_model_40.pth', map_location=device)
    #     model.load_state_dict(model_parameter)
    #
    model.train()
    total_loss = 0.0
    loss_epoch_data = []
    train_loader = tqdm(train_loader, file=sys.stdout)  # 显示进度条以epoch为统计基
    for inputs, targets in train_loader:
        inputs, targets = inputs.to(device), targets.to(device)

        optimizer.zero_grad()               # 梯度清零
        outputs = model(inputs)             # 预测结果

        # if epoch == 0 or epoch == 50 or epoch == 80:
        #     show_figures([inputs, outputs], format='BCHW', color=False, num=5, size=5, cmap=None)

        loss = criterion(outputs, targets)  # 计算损失
        loss.backward()                     # 反向传播
        optimizer.step()                    # 梯度优化
        total_loss += loss.item()           # 一个epoch多个batch的总损失

        loss_epoch_data.append(loss.data.cpu().numpy()) # 根据batch逐渐累计数据,获得一个epoch下的数据
        train_loader.desc = f"[train epoch {epoch}] | train loss: {loss.data.cpu().numpy():.8f}"

    return total_loss / len(train_loader), loss_epoch_data  # 一个batch的平均损失, 一个epoch下的损失

# 定义验证函数
def validate(model, model_state_dict, validation_loader, criterion, device, epoch):
    model.load_state_dict(model_state_dict)
    model.eval()
    total_loss = 0.0
    loss_epoch_data = []
    with torch.no_grad():
        validation_loader = tqdm(validation_loader, file=sys.stdout)  # 显示进度条以epoch为统计基
        for inputs, targets in validation_loader:
            inputs, targets = inputs.to(device), targets.to(device)

            outputs = model(inputs)
            loss = criterion(outputs, targets)

            total_loss += loss.item()

            loss_epoch_data.append(loss.data.cpu().numpy())  # 根据batch逐渐累计数据,获得一个epoch下的数据
            validation_loader.desc = f"[valid epoch {epoch}] | valid loss: {loss.data.cpu().numpy():.8f}"
    return total_loss / len(validation_loader), loss_epoch_data

class CustomLoss(nn.Module):
    """ MSE和SSIM加权损失"""
    def __init__(self, alpha=0.5, beta=0.5, window_size=11):        # 要求：alpha+beta=1
        super(CustomLoss, self).__init__()
        self.alpha = alpha
        self.beta = beta
        self.mse_loss = nn.MSELoss()                                # 计算MSE损失
        self.ssim_loss = SSIM(window_size=window_size)              # 创建SSIM对象

    def forward(self, y_pred, y_true):
        mse_loss = self.mse_loss(y_pred, y_true)                    # 计算MSE损失
        ssim_loss = 1 - self.ssim_loss(y_pred, y_true)              # 计算SSIM损失
        total_loss = self.alpha * mse_loss + self.beta * ssim_loss  # 组合损失
        return total_loss

def main(args, train_loader, validation_loader):
    # 设置参数
    device = torch.device(args.device)
    # 创建模型、损失函数和优化器
    model = MultiHeadAttentionDescriptor(args).to(device)
    criterion = CustomLoss(alpha=args.alpha, beta=args.beta, window_size=args.window_size)
    optimizer = torch.optim.AdamW(model.parameters(), lr=args.lr, weight_decay=5E-2)  # optimizer 使用 AdamW
    scheduler = torch.optim.lr_scheduler.ExponentialLR(optimizer, gamma=0.95)

    # 存储损失
    train_loss_all_epoch_data = []
    validation_loss_all_epoch_data = []
    # 在验证过程中保存在验证集上表现最好的模型
    best_validation_loss = float('inf')
    model_state_dict = model.state_dict()
    for epoch in range(args.epochs):
        train_loss, train_loss_epoch_data = train(model, train_loader, criterion, optimizer, device, epoch)
        validation_loss, validation_loss_epoch_data = validate(model, model_state_dict, validation_loader, criterion, device, epoch)
        # 使用调度器更新学习率
        scheduler.step()
        # 根据epoch逐渐累计损失,获得所有epoch下的损失
        train_loss_all_epoch_data.append(train_loss_epoch_data)
        validation_loss_all_epoch_data.append(validation_loss_epoch_data)
        # 存储Loss于.mat文件中
        save_data(r'LossInEpoch', '.mat', train_loss_all_epoch_data=train_loss_all_epoch_data, validation_loss_all_epoch_data=validation_loss_all_epoch_data)  # 可以存储任意多个

        # 保存在验证集上表现最好的模型
        if validation_loss < best_validation_loss:
            best_validation_loss = validation_loss
            # 更新最佳模型的参数
            model_state_dict = model.state_dict()
            # 存储最佳模型参数
            torch.save(model.state_dict(), 'ModelParameter/descriptor_model_'+str(epoch)+'.pth')
            print(f'当epoch = {epoch}, 验证集当前损失比先前损失小, 此时保存模型参数. 文件名称为: descriptor_model_{epoch}.pth')


if __name__ == '__main__':
    # 记录
    print('上一回训练开始于2023.12.18_11.50')
    # 设置随机数生成器的种子
    random.seed(666)  # 控制preprocessing_color的随机数
    np.random.seed(666)  # 控制Train_Validation_Dataset的随机数
    torch.manual_seed(666)  # 控制网络模型参数的随机数
    # 超参数
    parser = argparse.ArgumentParser(description='超参数：深度描述子网络')
    parser.add_argument('--root_path', type=str, default=r'E:\Paper3_Dateset\Train_Validation_Dataset', help='数据集根目录')  # E:\Paper3_Dateset\Train_Validation_Dataset
    parser.add_argument('--image_format_dataset', nargs='+', default=['.svs', '.jpg'], help='数据集中图像格式')
    parser.add_argument('--image_size', type=int, default=2048, help='输入模型的图像尺寸(high=wide)')
    parser.add_argument('--gabor_scales', nargs='+', type=int, default=[2, 4, 6], help='Gabor滤波器的多个尺度')
    parser.add_argument('--gabor_scales_len', type=int, default=None, help='Gabor的尺度深度=len(gabor_scales)')
    parser.add_argument('--ratio_train_validation', nargs='+', type=float, default=[0.8, 0.2], help='训练集和验证集的比例')
    parser.add_argument('--mask_ratio', type=float, default=0.7, help='图像遮蔽区域占总区域数目的随机比例上限(0.7:最高占70%)')
    parser.add_argument('--batch_size', type=int, default=1, help='批处理大小')
    parser.add_argument('--lr', type=float, default=0.00035, help='学习率')
    parser.add_argument('--epochs', type=int, default=100, help='训练的总轮数')
    parser.add_argument('--device', type=str, default='cuda:0' if torch.cuda.is_available() else 'cpu', help='设备,可选值为cuda或cpu')
    parser.add_argument('--alpha', type=float, default=0.5, help='MSE损失的权重,范围[0, 1], alpha+beta=1')
    parser.add_argument('--beta', type=float, default=0.5, help='SSIM损失的权重,范围[0, 1], alpha+beta=1')
    parser.add_argument('--window_size', type=int, default=11, help='计算SSIM损失的窗口尺寸,应为奇数')
    parser.add_argument('--times_add_dataset', type=int, default=3, help='原始数据集被利用的次数, 基于随机比例遮蔽图像区域, 增加数据量')
    parser.add_argument('--initial_channels', type=int, default=1, help='模型的数据初始深度')
    parser.add_argument('--base_channels', type=int, default=32, help='模型的基础扩展深度')
    parser.add_argument('--kernel_size_down', type=int, default=21, help='下采样过程卷积核的尺寸')
    args = parser.parse_args()
    # 超参数修订
    args.gabor_scales_len = len(args.gabor_scales)
    args.initial_channels = args.gabor_scales_len
    # 准备".csv"文件存储数据集路径
    dataset_paths, dataset_name, dataset_noformat_name = ReadAllFile_WindowsOrder(args.root_path, FileFormat=args.image_format_dataset[0])
    dataset_paths = ReadAllFile_FlattenedOrder(dataset_paths)
    dataset_paths_2, dataset_name_2, dataset_noformat_name_2 = ReadAllFile_WindowsOrder(args.root_path, FileFormat=args.image_format_dataset[1])
    dataset_paths_2 = ReadAllFile_FlattenedOrder(dataset_paths_2)
    dataset_paths.extend(dataset_paths_2)
    save_data(r'DatasetPath', '.csv', dataset_paths=dataset_paths)  # 存储数据集路径信息 # 如果需要可以存储任意多个变量
    # 随机划分训练集和验证集【idea: 训练与预测集被多次由于训练和预测模型，为了增加样本数量图像被遮蔽区域的比例是随机的，这被视为新的数据集】
    image_path_train, image_path_validation = split_train_validation_dataset(path=r'DatasetPath/dataset_paths.csv', ratio=args.ratio_train_validation)
    image_path_train = image_path_train * args.times_add_dataset
    image_path_validation = image_path_validation * args.times_add_dataset
    # 预处理
    data_transform = Compose([
        preprocessing_gray,
        Lambda(lambda x: preprocessing_size(x, target_size=args.image_size)),  # 在这里传递额外的参数 target_size,
        Lambda(lambda x: preprocessing_color(x, brightness_factor=(0.8, 1.2), contrast_factor=(0.8, 1.2), saturation_factor=(0.8, 1.2))),
        Lambda(lambda x: preprocessing_texture(x, scales=args.gabor_scales, orientations=8)),
        ToTensor(),  # 输入为unit8时, 将图像转换为[0, 1]范围的PyTorch张量
        Lambda(lambda x: preprocessing_mask_image(x,  r=args.mask_ratio*np.random.random(), n=16, p=0.5)),  # 随机遮蔽一定比例的输入数据(图)
        ])
    # 数据集【训练与验证集】
    train_data = TheDataset(path=image_path_train, transform=data_transform)
    validation_data = TheDataset(path=image_path_validation, transform=data_transform)
    NW = min([os.cpu_count(), args.batch_size if args.batch_size > 1 else 0, 10])  # number of workers
    train_loader = DataLoader(dataset=train_data, batch_size=args.batch_size, shuffle=True, pin_memory=True, num_workers=0)
    validation_loader = DataLoader(dataset=validation_data, batch_size=args.batch_size, shuffle=True, pin_memory=True, num_workers=0)
    # 训练与验证模型
    main(args, train_loader, validation_loader)
    text_sound('模型训练已完成.')























"""
# 语法：
1、

参数：
输出：
"""
# .............................................................................#
"""
# 小知识：
1、

"""
# .............................................................................#
"""
# 实施例：

"""
